import React, { useState, useEffect, useCallback } from 'react';
import { Clock, AlertCircle, CheckCircle, Lock } from 'lucide-react';

interface Question {
  id: number;
  type: 'multiple-choice' | 'short-answer' | 'long-answer' | 'true-false';
  question: string;
  options?: string[];
  required: boolean;
}

const questions: Question[] = [
  {
    id: 1,
    type: 'multiple-choice',
    question: 'What is the capital of France?',
    options: ['London', 'Berlin', 'Paris', 'Madrid'],
    required: true
  },
  {
    id: 2,
    type: 'short-answer',
    question: 'Explain the concept of photosynthesis in one sentence.',
    required: true
  },
  {
    id: 3,
    type: 'multiple-choice',
    question: 'Which of the following is a programming language?',
    options: ['HTML', 'CSS', 'JavaScript', 'All of the above'],
    required: true
  },
  {
    id: 4,
    type: 'true-false',
    question: 'The Earth is flat.',
    required: true
  },
  {
    id: 5,
    type: 'long-answer',
    question: 'Describe your understanding of climate change and its impact on the environment. (Minimum 100 words)',
    required: true
  },
  {
    id: 6,
    type: 'multiple-choice',
    question: 'What is 2 + 2?',
    options: ['3', '4', '5', '6'],
    required: true
  }
];

const ExamForm: React.FC = () => {
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [timeLeft, setTimeLeft] = useState(1800); // 30 minutes
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [warnings, setWarnings] = useState<string[]>([]);

  // Anti-cheat measures
  useEffect(() => {
    const disableCopyPaste = (e: KeyboardEvent) => {
      // Disable common keyboard shortcuts
      if (e.ctrlKey || e.metaKey) {
        const disabledKeys = ['c', 'v', 'x', 'a', 's', 'p', 'u', 'f', 'h', 'r', 'i', 'j'];
        if (disabledKeys.includes(e.key.toLowerCase())) {
          e.preventDefault();
          addWarning('Copy/paste functionality is disabled during the exam.');
        }
      }
      
      // Disable F12, F11, etc.
      if (e.key === 'F12' || e.key === 'F11' || e.key === 'F5') {
        e.preventDefault();
        addWarning('Developer tools and refresh are disabled during the exam.');
      }
    };

    const disableRightClick = (e: MouseEvent) => {
      e.preventDefault();
      addWarning('Right-click is disabled during the exam.');
    };

    const disableSelection = () => {
      document.body.style.userSelect = 'none';
      document.body.style.webkitUserSelect = 'none';
    };

    const handleVisibilityChange = () => {
      if (document.hidden) {
        addWarning('Warning: Tab switching detected. Please stay on the exam page.');
      }
    };

    // Add event listeners
    document.addEventListener('keydown', disableCopyPaste);
    document.addEventListener('contextmenu', disableRightClick);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    disableSelection();

    // Cleanup
    return () => {
      document.removeEventListener('keydown', disableCopyPaste);
      document.removeEventListener('contextmenu', disableRightClick);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  const addWarning = useCallback((warning: string) => {
    setWarnings(prev => {
      if (!prev.includes(warning)) {
        return [...prev, warning];
      }
      return prev;
    });
    setTimeout(() => {
      setWarnings(prev => prev.filter(w => w !== warning));
    }, 5000);
  }, []);

  // Timer functionality
  useEffect(() => {
    if (timeLeft > 0 && !isSubmitted) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !isSubmitted) {
      handleSubmit();
    }
  }, [timeLeft, isSubmitted]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerChange = (questionId: number, answer: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const handleSubmit = () => {
    setIsSubmitted(true);
    // Here you would typically send the answers to your backend
    console.log('Exam submitted:', answers);
  };

  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const currentQ = questions[currentQuestion];

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full text-center">
          <CheckCircle className="mx-auto mb-4 text-green-500\" size={64} />
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Exam Submitted Successfully!</h2>
          <p className="text-gray-600 mb-6">
            Your answers have been recorded. You may now close this window.
          </p>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="text-sm text-green-800">
              <strong>Questions Answered:</strong> {Object.keys(answers).length} / {questions.length}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      {/* Warnings */}
      {warnings.length > 0 && (
        <div className="fixed top-4 right-4 z-50 space-y-2">
          {warnings.map((warning, index) => (
            <div key={index} className="bg-red-500 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 animate-pulse">
              <AlertCircle size={16} />
              <span className="text-sm">{warning}</span>
            </div>
          ))}
        </div>
      )}

      {/* Header */}
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg mb-6">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
                  <Lock className="text-blue-600" size={24} />
                  Secure Online Examination
                </h1>
                <p className="text-gray-600 mt-1">Answer all questions to the best of your ability</p>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-2 text-lg font-semibold text-blue-600">
                  <Clock size={20} />
                  {formatTime(timeLeft)}
                </div>
                <p className="text-sm text-gray-500">Time remaining</p>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">
                Question {currentQuestion + 1} of {questions.length}
              </span>
              <span className="text-sm font-medium text-blue-600">
                {Math.round(progress)}% Complete
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="mb-6">
            <div className="flex items-start gap-3 mb-4">
              <span className="bg-blue-100 text-blue-800 text-sm font-semibold px-3 py-1 rounded-full">
                Q{currentQ.id}
              </span>
              {currentQ.required && (
                <span className="bg-red-100 text-red-800 text-xs font-medium px-2 py-1 rounded">
                  Required
                </span>
              )}
            </div>
            <h3 className="text-lg font-semibold text-gray-800 leading-relaxed">
              {currentQ.question}
            </h3>
          </div>

          {/* Question Input */}
          <div className="mb-6">
            {currentQ.type === 'multiple-choice' && (
              <div className="space-y-3">
                {currentQ.options?.map((option, index) => (
                  <label key={index} className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                    <input
                      type="radio"
                      name={`question-${currentQ.id}`}
                      value={option}
                      checked={answers[currentQ.id] === option}
                      onChange={(e) => handleAnswerChange(currentQ.id, e.target.value)}
                      className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                    />
                    <span className="ml-3 text-gray-700">{option}</span>
                  </label>
                ))}
              </div>
            )}

            {currentQ.type === 'true-false' && (
              <div className="space-y-3">
                {['True', 'False'].map((option) => (
                  <label key={option} className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                    <input
                      type="radio"
                      name={`question-${currentQ.id}`}
                      value={option}
                      checked={answers[currentQ.id] === option}
                      onChange={(e) => handleAnswerChange(currentQ.id, e.target.value)}
                      className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                    />
                    <span className="ml-3 text-gray-700">{option}</span>
                  </label>
                ))}
              </div>
            )}

            {currentQ.type === 'short-answer' && (
              <input
                type="text"
                value={answers[currentQ.id] || ''}
                onChange={(e) => handleAnswerChange(currentQ.id, e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
                placeholder="Enter your answer..."
                onCopy={(e) => e.preventDefault()}
                onPaste={(e) => e.preventDefault()}
              />
            )}

            {currentQ.type === 'long-answer' && (
              <textarea
                value={answers[currentQ.id] || ''}
                onChange={(e) => handleAnswerChange(currentQ.id, e.target.value)}
                rows={6}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors resize-none"
                placeholder="Enter your detailed answer..."
                onCopy={(e) => e.preventDefault()}
                onPaste={(e) => e.preventDefault()}
              />
            )}
          </div>
        </div>

        {/* Navigation */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
              disabled={currentQuestion === 0}
              className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Previous
            </button>

            <div className="flex gap-2">
              {questions.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentQuestion(index)}
                  className={`w-8 h-8 rounded-full text-sm font-medium transition-colors ${
                    index === currentQuestion
                      ? 'bg-blue-600 text-white'
                      : answers[questions[index].id]
                      ? 'bg-green-100 text-green-800'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {index + 1}
                </button>
              ))}
            </div>

            {currentQuestion === questions.length - 1 ? (
              <button
                onClick={handleSubmit}
                className="px-6 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors"
              >
                Submit Exam
              </button>
            ) : (
              <button
                onClick={() => setCurrentQuestion(Math.min(questions.length - 1, currentQuestion + 1))}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
              >
                Next
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExamForm;